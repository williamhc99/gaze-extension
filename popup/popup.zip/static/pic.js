 var img = []
 var i;
 for (i = 0; i<8 ; i++) {
	 img[i] = 'static/pictures/pic' + i + '.jpg'
 }

 function rand() {
	// generate image from pic0 to pic image.length-1
 	n = Math.floor((Math.random() * img.length))
 	return(img[n])
 }
 document.body.style.backgroundImage = "url(" + rand() + ")";
 // document.body.style


 // 	height: 100%;
	// width: 100%;
	// object-fit: cover;
	// position: absolute;
 // document.write("<img class='scale' src=" + rand()+ ">");
